const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/interviewAI")
.then(() => console.log("MongoDB Connected"))
.catch((err) => console.log(err));
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const model = genAI.getGenerativeModel({
  model: "gemini-2.5-flash",
});

// ---------------- SCHEMA ----------------
const ResultSchema = new mongoose.Schema({
  name: String,
  score: Number,
  answer: String,
  question: String,
  feedback: String,
  date: { type: Date, default: Date.now }
});

const Result = mongoose.model("Result", ResultSchema);

// ---------------- SAVE RESULT ----------------
app.post("/api/result", async (req, res) => {
  try {
    const { name, question, answer } = req.body;

    const prompt = `
You are an AI Interviewer.

Question:
${question}

Candidate Answer:
${answer}

Evaluate the answer and return only in this format:

Score: <number out of 100>
Feedback: <short feedback>
`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();
    
    console.log("Gemini Response:");
console.log(text);

    const scoreMatch = text.match(/Score:\s*(\d+)/i);
    const score = scoreMatch ? parseInt(scoreMatch[1]) : 0;

    const data = new Result({
      name,
      question,
      answer,
      score,
      feedback: text
    });

    await data.save();

    res.json({
      score,
      feedback: text,
    });

  } catch (error) {
    console.log(error);
    res.status(500).json({
      message: "AI Error"
    });
  }
});

// ---------------- GET RESULTS ----------------
app.get("/api/results", async (req, res) => {
  const data = await Result.find();
  res.send(data);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});