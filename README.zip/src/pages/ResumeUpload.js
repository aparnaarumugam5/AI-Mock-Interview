import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./ResumeUpload.css";

function ResumeUpload() {

  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("");
  const [file, setFile] = useState(null);

  const uploadResume = () => {

    if (!name || !email || !role || !file) {
      alert("Please fill all details and upload your resume.");
      return;
    }

    localStorage.setItem("candidateName", name);
    localStorage.setItem("candidateEmail", email);
    localStorage.setItem("candidateRole", role);
    localStorage.setItem("resumeUploaded", "true");
    localStorage.setItem("resumeName", file.name);

    alert("Resume Uploaded Successfully ✅");

    navigate("/interview");

  };

  return (

    <div className="resume">

      <h1>📄 Resume Upload</h1>

      <input
        type="text"
        placeholder="Enter Your Name"
        value={name}
        onChange={(e)=>setName(e.target.value)}
      />

      <input
        type="email"
        placeholder="Enter Your Email"
        value={email}
        onChange={(e)=>setEmail(e.target.value)}
      />

      <select
        value={role}
        onChange={(e)=>setRole(e.target.value)}
      >
        <option value="">Select Role</option>
        <option>Frontend Developer</option>
        <option>Backend Developer</option>
        <option>Full Stack Developer</option>
        <option>Java Developer</option>
        <option>Python Developer</option>
        <option>React Developer</option>
      </select>

      <input
        type="file"
        accept=".pdf,.doc,.docx"
        onChange={(e)=>setFile(e.target.files[0])}
      />

      {file && (
        <p>
          📄 {file.name}
        </p>
      )}

      <button onClick={uploadResume}>
        Upload Resume
      </button>

    </div>

  );

}

export default ResumeUpload;