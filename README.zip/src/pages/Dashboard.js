import React from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

function Dashboard() {

  const navigate = useNavigate();

  const uploaded =
    localStorage.getItem("resumeUploaded") === "true";

  const resumeName =
    localStorage.getItem("resumeName");

  return (

    <div className="dashboard">

      <h1>📊 Dashboard</h1>

      <h2>Welcome 👋</h2>

      <div className="cards">

        <div className="card">
          <h3>Total Interviews</h3>
          <h1>5</h1>
        </div>

        <div className="card">
          <h3>Best Score</h3>
          <h1>92%</h1>
        </div>

        <div className="card">
          <h3>Average Score</h3>
          <h1>85%</h1>
        </div>

        <div className="card">
          <h3>Resume Status</h3>

          {uploaded ? (
            <>
              <h2 style={{ color: "green" }}>
                Uploaded ✅
              </h2>

              <p>{resumeName}</p>
            </>
          ) : (
            <>
              <h2 style={{ color: "red" }}>
                Not Uploaded ❌
              </h2>
            </>
          )}

        </div>

      </div>

      <br />

      {!uploaded && (

        <button
          onClick={() => navigate("/resume")}
        >
          📄 Upload Resume
        </button>

      )}

      <br /><br />

      <button
        onClick={() => navigate("/interview")}
      >
        🎤 Start Interview
      </button>

    </div>

  );

}

export default Dashboard;