import React from "react";
import { useNavigate } from "react-router-dom";

function Result() {
  const navigate = useNavigate();

  // localStorage இருந்து data get (Interview.js la store pannirukanum)
  const score = localStorage.getItem("score");
  const answer = localStorage.getItem("answer");
  const question = localStorage.getItem("question");

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>🎯 Interview Result</h2>

      {/* SCORE */}
      <div
        style={{
          padding: "10px",
          border: "1px solid black",
          marginBottom: "20px"
        }}
      >
        <h3>Score: {score || 0}/100</h3>
      </div>

      {/* QUESTION */}
      <h3>Question:</h3>
      <p>{question}</p>

      {/* ANSWER (AI SPEECH STYLE BOX) */}
      <h3>Your Answer:</h3>
      <div
        style={{
          padding: "15px",
          borderRadius: "10px",
          background: "#f4f4f4",
          minHeight: "100px",
          whiteSpace: "pre-wrap",
          fontSize: "16px",
          lineHeight: "1.5"
        }}
      >
        {answer ? answer : "No answer recorded"}
      </div>

      {/* BUTTON */}
      <button
        onClick={() => navigate("/dashboard")}
        style={{
          marginTop: "20px",
          padding: "10px 20px",
          background: "black",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer"
        }}
      >
        ⬅ Back to Dashboard
      </button>
    </div>
  );
}

export default Result;