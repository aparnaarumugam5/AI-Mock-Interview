import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./Result.css";

function Result() {
  const navigate = useNavigate();

  const [result, setResult] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/results")
      .then((res) => {
        if (res.data.length > 0) {
          // Latest interview result
          setResult(res.data[res.data.length - 1]);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  if (!result) {
    return <h2 style={{ textAlign: "center" }}>Loading...</h2>;
  }

  const score = result.score;
  const total = 100;

  let feedback = "";

  if (score >= 90) {
    feedback = "Excellent Performance 🎉";
  } else if (score >= 75) {
    feedback = "Very Good 👍";
  } else if (score >= 60) {
    feedback = "Good. Keep Practicing 😊";
  } else {
    feedback = "Needs Improvement 💪";
  }

  return (
    <div className="result">

      <h1>🎯 Interview Result</h1>

      <div className="score-card">
        <h2>Your Score</h2>

        <h1>{score} / {total}</h1>

        <h3>{feedback}</h3>
      </div>

      <div className="analysis">

        <h2>Question</h2>
        <p>{result.question}</p>

        <h2>Your Answer</h2>
        <p>{result.answer}</p>

        <h2>Date</h2>
        <p>{new Date(result.date).toLocaleString()}</p>

      </div>

      <br />

      <button onClick={() => navigate("/dashboard")}>
        Go To Dashboard
      </button>

      <button onClick={() => navigate("/interview")}>
        Try Again
      </button>

    </div>
  );
}

export default Result;