import { useNavigate } from "react-router-dom";
import "./Login.css";

function Login() {

  const navigate = useNavigate();

  const login = (e) => {
    e.preventDefault();

    // Login success
    navigate("/resume");
  };

  return (
    <div className="login-container">
      <h1>Login</h1>

      <form onSubmit={login}>

        <input
          type="email"
          placeholder="Enter Email"
          required
        />

        <input
          type="password"
          placeholder="Enter Password"
          required
        />

        <button type="submit">
          Login
        </button>

      </form>
    </div>
  );
}

export default Login;