import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import "./Interview.css";
import axios from "axios";

function Interview() {
  const navigate = useNavigate();

  const questions = [
    "Tell me about yourself.",
    "Why do you want to join our company?",
    "What are your strengths?",
    "What are your weaknesses?",
    "Explain React.",
    "What is Virtual DOM?",
    "Difference between let, var and const?",
    "Explain useState Hook.",
    "Explain useEffect Hook.",
    "Where do you see yourself in five years?"
  ];

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answer, setAnswer] = useState("");

  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  // Convert speech to text continuously
  useEffect(() => {
    setAnswer(transcript);
  }, [transcript]);

  // Speak question automatically
  useEffect(() => {
    if (browserSupportsSpeechRecognition) {
      window.speechSynthesis.cancel();

      const speech = new SpeechSynthesisUtterance(
        questions[currentQuestion]
      );

      speech.lang = "en-US";
      speech.rate = 1;
      speech.pitch = 1;

      window.speechSynthesis.speak(speech);
    }
  }, [currentQuestion, browserSupportsSpeechRecognition]);

  if (!browserSupportsSpeechRecognition) {
    return (
      <h2 style={{ textAlign: "center", marginTop: "100px" }}>
        Speech Recognition is not supported in this browser.
      </h2>
    );
  }

  const startListening = () => {
    resetTranscript();
    setAnswer("");

    SpeechRecognition.startListening({
      continuous: true,
      language: "en-US",
    });
  };

  const stopListening = () => {
    SpeechRecognition.stopListening();
    console.log("User Answer:", answer);
  };

  const nextQuestion = async () => {
  SpeechRecognition.stopListening();

  try {
    const response = await axios.post(
  "http://localhost:5000/api/result",
  {
    name: "User",
    question: questions[currentQuestion],
    answer: answer,
  }
);

console.log("AI Score:", response.data.score);
console.log("Feedback:", response.data.feedback);

    console.log("Saved Successfully");
  } catch (err) {
    console.error("Save Error:", err);
  }

  if (currentQuestion < questions.length - 1) {
    setCurrentQuestion(currentQuestion + 1);
    resetTranscript();
    setAnswer("");
  } else {
    alert("Interview Completed Successfully");
    navigate("/result");
  }
};

  return (
    <div className="interview-container">

      <h1>🤖 AI Mock Interview</h1>

      <h2>
        Question {currentQuestion + 1} of {questions.length}
      </h2>

      <div className="question-box">
        {questions[currentQuestion]}
      </div>

      <button
        onClick={() =>
          window.speechSynthesis.speak(
            new SpeechSynthesisUtterance(
              questions[currentQuestion]
            )
          )
        }
      >
        🔊 Repeat Question
      </button>

      <br /><br />

      <button onClick={startListening}>
        🎤 Start Recording
      </button>

      <button onClick={stopListening}>
        ⏹ Stop Recording
      </button>

      <h3>
        Status :
        {listening ? " 🟢 Listening..." : " 🔴 Stopped"}
      </h3>

      <textarea
        rows="10"
        cols="80"
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
        placeholder="Speak or type your answer here..."
      />

      <br /><br />

      <button onClick={nextQuestion}>
        Next Question ➜
      </button>

    </div>
  );
}

export default Interview;
// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import SpeechRecognition, {
//   useSpeechRecognition,
// } from "react-speech-recognition";
// import "./Interview.css";

// function Interview() {
//   const navigate = useNavigate();

//   const questions = [
//     "Tell me about yourself.",
//     "Why do you want to join our company?",
//     "What are your strengths?",
//     "What are your weaknesses?",
//     "Explain React.",
//     "What is Virtual DOM?",
//     "Difference between let, var and const?",
//     "Explain useState Hook.",
//     "Explain useEffect Hook.",
//     "Where do you see yourself in five years?"
//   ];

//   const [currentQuestion, setCurrentQuestion] = useState(0);

//   const {
//     transcript,
//     listening,
//     resetTranscript,
//     browserSupportsSpeechRecognition,
//   } = useSpeechRecognition();

//   useEffect(() => {
//     if (browserSupportsSpeechRecognition) {
//       window.speechSynthesis.cancel();

//       const speech = new SpeechSynthesisUtterance(
//         questions[currentQuestion]
//       );

//       speech.lang = "en-US";
//       speech.rate = 1;
//       speech.pitch = 1;

//       window.speechSynthesis.speak(speech);
//     }
//   }, [currentQuestion, browserSupportsSpeechRecognition]);

//   if (!browserSupportsSpeechRecognition) {
//     return (
//       <h2 style={{ textAlign: "center", marginTop: "100px" }}>
//         Speech Recognition is not supported in this browser.
//       </h2>
//     );
//   }

//   const startListening = () => {
//     resetTranscript();

//     SpeechRecognition.startListening({
//       continuous: true,
//       language: "en-US",
//     });
//   };

//   const stopListening = () => {
//     SpeechRecognition.stopListening();
//   };

//   const nextQuestion = () => {
//     SpeechRecognition.stopListening();

//     if (currentQuestion < questions.length - 1) {
//       setCurrentQuestion(currentQuestion + 1);
//       resetTranscript();
//     } else {
//       alert("Interview Completed Successfully");
//       navigate("/result");
//     }
//   };
//   return (
//     <div className="interview-container">

//       <h1>🤖 AI Mock Interview</h1>

//       <h2>
//         Question {currentQuestion + 1} of {questions.length}
//       </h2>

//       <div className="question-box">
//         {questions[currentQuestion]}
//       </div>

//       <button onClick={() => window.speechSynthesis.speak(
//         new SpeechSynthesisUtterance(questions[currentQuestion])
//       )}>
//         🔊 Repeat Question
//       </button>

//       <br /><br />

//       <button onClick={startListening}>
//         🎤 Start Recording
//       </button>

//       <button onClick={stopListening}>
//         ⏹ Stop Recording
//       </button>

//       <h3>
//         Status :
//         {listening ? " 🟢 Listening..." : " 🔴 Stopped"}
//       </h3>

//       <textarea
//         rows="10"
//         cols="80"
//         value={transcript}
//         readOnly
//         placeholder="Your spoken answer will appear here..."
//       />

//       <br /><br />

//       <button onClick={nextQuestion}>
//         Next Question ➜
//       </button>

//     </div>
//   );
// }

// export default Interview;